### Screenshotpath

Python package that changes your screenshot path on MacOS.

### Usage

`screenshotpath <PATH>`